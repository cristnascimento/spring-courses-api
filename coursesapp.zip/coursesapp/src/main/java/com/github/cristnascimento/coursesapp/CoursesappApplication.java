package com.github.cristnascimento.coursesapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CoursesappApplication {

	public static void main(String[] args) {
		SpringApplication.run(CoursesappApplication.class, args);
	}

}
